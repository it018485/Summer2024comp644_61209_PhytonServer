#populate tb_emp
#12-7-21
#8-20-22
-- SELECT version();

USE db_sql_fall_2023;

#populate the employee table
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (100, 'James P. Cash', '2015-01-01' , NULL, 1, 'Jefe', '2021-06-12T17:27:12.940' , 2);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (101, 'Patrick Williams', '2021-05-01' , 100, 1, 'Unit eight however bar. Ten live bag probably call dream point.
Career staff social dark do. Whose present owner key include. Wait kind report example hand development.', '2021-06-12T17:28:11.210' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (102, 'Ernest Herma', '2021-04-03' , 100, 1, 'Pressure environment interest pass. Project class light sea. Buy force security line time well by car. Game statement threat adult small future anything onto.', '2021-06-12T17:28:11.210' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (103, 'Christine Fernandez', '2021-03-04' , 100, 1, 'Window list decide. Cut exactly pay perform best process serious.
Participant among force detail eye natural meet development. Fly whether fire trial.', '2021-06-12T17:28:11.213' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (104, 'Steven Rich', '2021-03-30' , 100, 1, 'Energy place spring. Wrong close doctor production well life may. Federal manager finish best and citizen position.', '2021-06-12T17:28:11.217' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (105, 'Charles Martinez', '2021-03-24' , 100, 1, 'South carry business view down have. Fly capital knowledge between on.
Product measure father just important light. Game parent prepare standard town. Really pretty specific them key bag.', '2021-06-12T17:28:11.220' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (106, 'Molly Garcia', '2021-05-15' , 100, 1, 'Simply development hit occur left. Design somebody new claim. Compare address hard themselves total senior.
How poor air animal war fly series under.', '2021-06-12T17:28:11.220' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (107, 'Jonathan Arroyo', '2021-02-20' , 100, 1, 'Mother economy performance return example outside lawyer. Present TV pressure good.
Price network risk alone. Price generation financial south move similar report. Task herself ten remain determine.', '2021-06-12T17:28:11.223' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (108, 'Emily Mcknight', '2021-03-06' , 100, 1, 'Fire buy vote institution difference. Wear throw well.
Official with per record budget fine claim. Part girl suddenly song billion. Particularly organization everybody on concern professor building.', '2021-06-12T17:28:11.227' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (109, 'Jessica Sharp', '2021-05-23' , 100, 1, 'Exist seek budget difficult similar cost process data.
Good none much clearly man art. Himself bill watch four present loss.
Worker once trouble break go. True field list wish. Senior avoid other.', '2021-06-12T17:28:11.227' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (110, 'Emily Ray', '2021-01-07' , 101, 1, 'Fish beautiful wind third. Policy push become product player. Top police care away compare.', '2021-06-12T17:34:40.263' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (111, 'Stephanie Dorsey', '2021-06-01' , 101, 1, 'Book year when turn enough reveal detail. Evidence become news however.
Listen hotel bad campaign. Home interview story friend. Reach couple deep me decide.', '2021-06-12T17:34:40.267' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (112, 'Jared Harris', '2021-03-01' , 104, 1, 'Company training live career. Green according ago. Remain role summer hit myself young present.
Lead impact bring senior toward rise project seven. Can general rich consider believe school mean.', '2021-06-12T17:34:40.270' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (113, 'Jessica Scott', '2021-05-25' , 102, 1, 'Act he remain free bad size across describe. Game provide itself third during. Suddenly eye happy author left.
Assume air fall meet gas. Take tree some name sure tell.', '2021-06-12T17:34:40.270' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (114, 'Steven Shelto', '2021-04-25' , 101, 1, 'Body action production people within particularly themselves try. First one relationship visit.
Hotel Democrat gas half.
Determine box side for. Pull save participant sure scene however remember.', '2021-06-12T17:34:40.273' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (115, 'Seth Ward', '2021-05-10' , 101, 1, 'Name difference everything despite. Seek build most time near today himself. Congress nice more new next medical.
Agreement college gun.', '2021-06-12T17:34:40.277' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (116, 'Michael Wright', '2021-02-20' , 103, 1, 'Beat little set during just. Far center occur degree great study mouth.
Talk happen life hotel difficult cut money. Region well thought wrong reality. There finally chair authority get.', '2021-06-12T17:34:40.280' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (117, 'Jake Baker', '2021-02-19' , 106, 1, 'Brother be stuff measure create trial. Herself money establish relationship risk left story. Firm past soon through him research.', '2021-06-12T17:34:40.280' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (118, 'Sean Clark', '2021-04-19' , 104, 1, 'Lawyer painting single over staff already his. Police major leader product dark.', '2021-06-12T17:34:40.283' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (119, 'Sean Pacheco', '2021-05-16' , 105, 1, 'Director really chair after for loss student century. Until world understand call oil strong. Event personal Democrat name.', '2021-06-12T17:34:40.283' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (120, 'Brandon Anderso', '2021-01-09' , 103, 1, 'Safe population third minute simply rich which. Issue blood soldier not position quite modern. Degree that maybe one walk foot network.', '2021-06-12T17:34:40.287' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (121, 'John Evans', '2021-02-22' , 107, 1, 'Fact choice enough degree live. At sure attention or five. Structure sell great player.
Though forget body ahead majority. Since step couple group read.', '2021-06-12T17:34:40.290' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (122, 'Phillip Thompso', '2021-05-16' , 106, 1, 'More account effect who decade. Fund fine run subject image budget prevent. Participant American pick military after forget.', '2021-06-12T17:34:40.293' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (123, 'John Fernandez', '2021-03-30' , 109, 1, 'Order father put dark center hotel. Every because team require well indeed fill myself.', '2021-06-12T17:34:40.293' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (124, 'Roger Warre', '2021-02-18' , 101, 1, 'Structure rate reason especially nothing key. Performance pressure history than generation president. Particularly light firm listen herself wonder scientist.', '2021-06-12T17:34:40.297' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (125, 'Juan Miller', '2021-05-03' , 102, 1, 'Which perform interest soldier have east money. Seek rest country. Whose defense make court instead. Idea because green eye fact best thus.', '2021-06-12T17:34:40.300' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (126, 'Jennifer Salinas', '2021-05-19' , 106, 1, 'Themselves stand any. Also moment book design.
Machine house big join Mr time yes. Fear face budget require group behavior ability. Term resource need carry keep follow write.', '2021-06-12T17:34:40.300' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (127, 'David Russo', '2021-02-07' , 106, 1, 'American above candidate enjoy media wall. First especially late high anything cold. Despite war none cover low station.', '2021-06-12T17:34:40.303' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (128, 'Jacob Barrett', '2021-02-27' , 107, 1, 'Age popular inside make.
Meeting receive help represent drop generation gas full.
Evening raise nation north plan high road. Visit knowledge education address. Past prevent concern represent.', '2021-06-12T17:34:40.307' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (129, 'Christopher Smith', '2021-04-14' , 107, 1, 'Left next attention exist start. Sing even computer thus clearly wait challenge paper. Deal work social explain attention wrong.
Anyone development information eye.', '2021-06-12T17:34:40.310' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (130, 'Dalton Robertso', '2021-05-30' , 108, 1, 'Return rather article there. Truth society trouble woman year. Catch very value such person continue put break. Begin science short reality base while pretty.', '2021-06-12T17:34:40.310' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (131, 'Allen Beard', '2021-04-21' , 101, 1, 'Every nice tend eight box impact. Father bill blue president including.
Always plan kind throughout eight seem measure finally. Thus think skill every serve good admit.', '2021-06-12T17:34:40.313' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (132, 'Brittany Winters', '2021-04-17' , 101, 1, 'Itself especially important mind. His identify member discussion why street. Condition exactly six short four center.', '2021-06-12T17:34:40.317' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (133, 'Brad Perry', '2021-04-30' , 107, 1, 'Have also Congress minute woman save health. Goal worry become.', '2021-06-12T17:34:40.317' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (134, 'Thomas Weaver', '2021-01-25' , 109, 1, 'Her down military across. Carry citizen close which stock indeed. Quickly according question situation memory try adult.', '2021-06-12T17:34:40.320' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (135, 'Craig Jimenez', '2021-05-15' , 105, 1, 'Author seat member time way. Tv nothing red herself team include well. Weight best art pressure camera we.', '2021-06-12T17:34:40.323' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (136, 'Justin Erickso', '2021-01-10' , 101, 1, 'Dinner lead three without. Least possible challenge yourself choice.
Such full state work blood clear.
Four close education at your something fund cell. Usually dinner standard subject one machine.', '2021-06-12T17:34:40.327' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (137, 'Madison Baker DDS', '2021-05-04' , 109, 1, 'Election man hundred seem direction movie condition. West opportunity its southern avoid bring.
Trial he describe campaign political. Standard go card assume. Particular director world wall glass.', '2021-06-12T17:34:40.330' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (138, 'Brandy Wong', '2021-03-31' , 105, 1, 'Team gas cost themselves. If service court certainly board start. Thank pretty great course lawyer bag.', '2021-06-12T17:34:40.330' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (139, 'James Dawso', '2021-05-29' , 101, 1, 'Later system early foot. Machine peace where. According great never another scene pretty value.
Character too site develop. System room fire agree difficult ok teacher.', '2021-06-12T17:34:40.333' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (140, 'Nicole Rodriguez', '2021-03-13' , 104, 1, 'Wish trial trouble level hospital name network.
Mind body already staff. Else travel heavy.
Ask already effort add also.', '2021-06-12T17:34:40.337' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (141, 'Marissa Thompson DDS', '2021-01-21' , 107, 1, 'Seek alone little PM responsibility.
Strong detail kind serve artist after also. Hand statement year involve degree north late. Investment owner describe.', '2021-06-12T17:34:40.337' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (142, 'Elizabeth Henso', '2021-04-08' , 108, 1, 'Police health to wish. At eye positive attack charge effect.
Act just increase team. Treatment after ok federal doctor see. Single sea him top.', '2021-06-12T17:34:40.340' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (143, 'Christopher Dunca', '2021-03-31' , 104, 1, 'Actually east best floor cut thus. Manager glass hot significant.
Once boy see perform American cut. Region assume happen note food.', '2021-06-12T17:34:40.343' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (144, 'Sheryl Smith', '2021-02-14' , 102, 1, 'Evidence first bank man follow who loss clear. Expert church trip main. Here successful until skin. Card education kind already card doctor question.', '2021-06-12T17:34:40.343' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (145, 'David Reynolds', '2021-02-17' , 107, 1, 'Compare not travel. Western friend raise direction region make. Realize window economic learn discussion east.', '2021-06-12T17:34:40.347' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (146, 'Mary Anthony', '2021-01-12' , 104, 1, 'Probably benefit full style do process certainly. Development seven concern so safe no plan. Candidate than bag head.
Go wrong service very. Official big through wind. Indicate real agent plan.', '2021-06-12T17:34:40.350' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (147, 'Anthony Goodma', '2021-04-18' , 105, 1, 'Special give board job me focus west. Drive our physical pull beat draw. Benefit relate exist alone determine finish necessary.', '2021-06-12T17:34:40.350' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (148, 'Taylor Romero', '2021-02-05' , 109, 1, 'Theory rest area him computer others.
Word day able camera maintain. Capital later group continue another order nearly.', '2021-06-12T17:34:40.353' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (149, 'Kathy Reed', '2021-02-19' , 101, 1, 'Agree until report defense conference too by. Expert whatever science theory fire go old occur. Describe themselves officer kind. Specific become again country security local bring.', '2021-06-12T17:34:40.357' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (150, 'Sandy Mays', '2021-05-12' , 103, 1, 'Discover worker much late. Owner natural onto pattern cover different message.
Herself out seem carry common state degree more. Analysis positive operation meet four why.', '2021-06-12T17:34:40.360' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (151, 'Justin Montgomery', '2021-06-05' , 109, 1, 'Change professional deal summer heart budget. Everyone produce gas right company store popular.
Actually option front walk within. Lose off good modern. Size final a respond guy democratic.', '2021-06-12T17:34:40.360' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (152, 'Julie Woodward', '2021-02-06' , 107, 1, 'Detail right nearly.
Well heavy newspaper join. Tough appear watch show begin. Budget idea behavior up quickly.
Campaign deep home parent many. Reveal compare pass loss.', '2021-06-12T17:34:40.363' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (153, 'Carlos Watso', '2021-03-31' , 102, 1, 'Cause leave risk follow season. Make two record fish compare.
Author dinner future. Top reveal north to party.
More among respond raise quickly much gas trial. Maintain heavy national modern.', '2021-06-12T17:34:40.363' , 3);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (154, 'Sarah Humphrey', '2021-03-30' , 103, 1, 'Serve wide become whether. List particular social risk. Down help student manage.', '2021-06-12T17:34:40.367' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (155, 'Kimberly Marti', '2021-01-16' , 102, 1, 'Pretty news necessary not.
Senior local theory ok another bank. One special direction series here success.', '2021-06-12T17:34:40.370' , 1);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (156, 'Matthew Carter', '2021-01-10' , 103, 1, 'Operation another social walk plant word enjoy. Yet local set worry assume tell tree. Land never member address floor.', '2021-06-12T17:34:40.370' , 5);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (157, 'Amy Valdez', '2021-04-17' , 102, 1, 'Available and growth many during with attorney. Discussion miss five play house soldier while. Improve eat low.
Will still size structure data hand third prevent. Article American plan idea.', '2021-06-12T17:34:40.373' , 4);
INSERT   tb_emp  ( emp_id_pk ,  emp_name ,  emp_hire_dt ,  emp_reports_to_fk ,  emp_is_active ,  emp_notes ,  emp_create_dt ,  dept_id_fk ) VALUES (158, 'Sara Johnso', '2021-02-12' , 103, 1, 'Knowledge stop step whom other those appear. Practice painting compare letter. Hope control here east gas rock.
Maybe garden live benefit call national minute.','2021-06-12T17:34:40.377' , 4);

SELECT * 
FROM tb_emp
ORDER BY
    emp_id_pk DESC;
